const EMAIL_DESTINO = "douglas.silva@niu.pt";
const EMAIL_REMETENTE = "onboarding@resend.dev"; // troque após verificar domínio próprio no Resend

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
  });
}

async function enviarEmail(env, { item, quantidade, unidade, ot, solicitante, setor }) {
  if (!env.RESEND_API_KEY) return;
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: EMAIL_REMETENTE,
        to: EMAIL_DESTINO,
        subject: `📋 Nova solicitação: ${item} (OT ${ot})`,
        html: `
        <div style="background:#0f1115;padding:32px;font-family:-apple-system,Helvetica,Arial,sans-serif">
          <div style="max-width:420px;margin:0 auto;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:18px;padding:26px;backdrop-filter:blur(10px)">
            <div style="font-size:13px;color:#9aa3b2;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Nova solicitação de material</div>
            <div style="font-size:21px;font-weight:700;color:#fff;margin-bottom:18px">${item}</div>
            <table style="width:100%;font-size:14px;color:#e2e6ed;border-collapse:collapse">
              <tr><td style="padding:6px 0;color:#9aa3b2">Quantidade</td><td style="padding:6px 0;text-align:right;font-weight:600">${quantidade} ${unidade || ""}</td></tr>
              <tr style="border-top:1px solid rgba(255,255,255,.1)"><td style="padding:6px 0;color:#9aa3b2">OT</td><td style="padding:6px 0;text-align:right;font-weight:600">${ot}</td></tr>
              <tr style="border-top:1px solid rgba(255,255,255,.1)"><td style="padding:6px 0;color:#9aa3b2">Solicitante</td><td style="padding:6px 0;text-align:right;font-weight:600">${solicitante}</td></tr>
              <tr style="border-top:1px solid rgba(255,255,255,.1)"><td style="padding:6px 0;color:#9aa3b2">Setor</td><td style="padding:6px 0;text-align:right;font-weight:600">${setor || "-"}</td></tr>
            </table>
          </div>
        </div>`
      })
    });
  } catch (e) {
    console.log("Falha ao enviar e-mail:", e);
  }
}

async function enviarEmailLote(env, { ot, solicitante, setor, itens }) {
  if (!env.RESEND_API_KEY) return;
  const linhas = itens.map(i => `
    <tr><td style="padding:6px 0;color:#e2e6ed">${i.item}</td><td style="padding:6px 0;text-align:right;font-weight:600;color:#e2e6ed">${i.quantidade}</td></tr>
  `).join("");
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: EMAIL_REMETENTE,
        to: EMAIL_DESTINO,
        subject: `Nova solicitação (OT ${ot}) — ${itens.length} item(ns)`,
        html: `
        <div style="background:#0f1115;padding:32px;font-family:-apple-system,Helvetica,Arial,sans-serif">
          <div style="max-width:440px;margin:0 auto;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:18px;padding:26px;backdrop-filter:blur(10px)">
            <div style="font-size:13px;color:#9aa3b2;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Nova solicitação de material</div>
            <div style="font-size:21px;font-weight:700;color:#fff;margin-bottom:14px">OT ${ot}</div>
            <table style="width:100%;font-size:14px;border-collapse:collapse;margin-bottom:14px">
              <tr style="border-bottom:1px solid rgba(255,255,255,.15)"><td style="padding:6px 0;color:#9aa3b2">Item</td><td style="padding:6px 0;text-align:right;color:#9aa3b2">Qtd.</td></tr>
              ${linhas}
            </table>
            <table style="width:100%;font-size:13px;color:#e2e6ed;border-collapse:collapse">
              <tr style="border-top:1px solid rgba(255,255,255,.1)"><td style="padding:6px 0;color:#9aa3b2">Solicitante</td><td style="padding:6px 0;text-align:right;font-weight:600">${solicitante}</td></tr>
              <tr style="border-top:1px solid rgba(255,255,255,.1)"><td style="padding:6px 0;color:#9aa3b2">Setor</td><td style="padding:6px 0;text-align:right;font-weight:600">${setor || "-"}</td></tr>
            </table>
          </div>
        </div>`
      })
    });
  } catch (e) { console.log("Falha ao enviar e-mail:", e); }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    if (method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type"
        }
      });
    }

    // ---------- ITENS ----------
    if (path === "/api/itens" && method === "GET") {
      const { results } = await env.DB.prepare("SELECT * FROM itens ORDER BY nome").all();
      return json(results);
    }

    const itemGetMatch = path.match(/^\/api\/itens\/(\d+)$/);
    if (itemGetMatch && method === "GET") {
      const item = await env.DB.prepare("SELECT * FROM itens WHERE id = ?").bind(itemGetMatch[1]).first();
      return item ? json(item) : json({ error: "Not found" }, 404);
    }

    if (path === "/api/solicitacoes" && method === "GET") {
      const item_id = url.searchParams.get("item_id");
      const status = url.searchParams.get("status");
      let query = "SELECT * FROM solicitacoes WHERE 1=1";
      const binds = [];
      if (item_id) { query += " AND item_id = ?"; binds.push(item_id); }
      if (status === "aberto") { query += " AND status != 'devolvido'"; }
      query += " ORDER BY data DESC";
      const { results } = await env.DB.prepare(query).bind(...binds).all();
      return json(results);
    }

    if (path === "/api/itens" && method === "POST") {
      const b = await request.json();
      const r = await env.DB.prepare(
        "INSERT INTO itens (nome, categoria, quantidade, unidade, modelo, voltagem, codigo) VALUES (?, ?, ?, ?, ?, ?, ?)"
      ).bind(b.nome, b.categoria || "Outro", b.quantidade || 0, b.unidade || "un", b.modelo || "", b.voltagem || "", b.codigo || "").run();
      return json({ id: r.meta.last_row_id });
    }

    const itemMatch = path.match(/^\/api\/itens\/(\d+)$/);
    if (itemMatch && method === "PATCH") {
      const id = itemMatch[1];
      const b = await request.json();
      if (b.delta !== undefined) {
        await env.DB.prepare("UPDATE itens SET quantidade = quantidade + ? WHERE id = ?").bind(b.delta, id).run();
      } else {
        await env.DB.prepare(
          "UPDATE itens SET nome=?, categoria=?, quantidade=?, unidade=?, modelo=?, voltagem=?, codigo=? WHERE id=?"
        ).bind(b.nome, b.categoria, b.quantidade, b.unidade, b.modelo || "", b.voltagem || "", b.codigo || "", id).run();
      }
      return json({ ok: true });
    }

    if (itemMatch && method === "DELETE") {
      await env.DB.prepare("DELETE FROM itens WHERE id = ?").bind(itemMatch[1]).run();
      return json({ ok: true });
    }

    // ---------- NOTIFICAÇÕES (para sino do painel) ----------
    if (path === "/api/notificacoes" && method === "GET") {
      const since = url.searchParams.get("since") || "1970-01-01";
      const { results } = await env.DB.prepare(
        "SELECT * FROM solicitacoes WHERE data > ? ORDER BY data DESC LIMIT 20"
      ).bind(since).all();
      return json(results);
    }

    // ---------- CATEGORIAS ----------
    if (path === "/api/categorias" && method === "GET") {
      const { results } = await env.DB.prepare("SELECT DISTINCT categoria FROM itens ORDER BY categoria").all();
      return json(results.map(r => r.categoria));
    }

    if (path === "/api/solicitacoes/lote" && method === "POST") {
      const b = await request.json();
      const { ot, solicitante, setor, itens: lista } = b;
      if (!ot || !solicitante || !Array.isArray(lista) || lista.length === 0) {
        return json({ error: "Dados incompletos" }, 400);
      }
      const resultado = [];
      for (const li of lista) {
        const item = await env.DB.prepare("SELECT * FROM itens WHERE id = ?").bind(li.itemId).first();
        if (!item || item.quantidade < li.quantidade) {
          return json({ error: `Quantidade indisponível para ${item ? item.nome : li.itemId}` }, 400);
        }
      }
      for (const li of lista) {
        const item = await env.DB.prepare("SELECT * FROM itens WHERE id = ?").bind(li.itemId).first();
        await env.DB.prepare(
          "INSERT INTO solicitacoes (item_id, item_nome, unidade, quantidade, ot, solicitante, setor, local_uso) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        ).bind(li.itemId, item.nome, item.unidade, li.quantidade, ot, solicitante, setor || "", li.localUso || "").run();
        await env.DB.prepare("UPDATE itens SET quantidade = quantidade - ? WHERE id = ?").bind(li.quantidade, li.itemId).run();
        resultado.push({ item: item.nome, quantidade: li.quantidade });
      }
      await enviarEmailLote(env, { ot, solicitante, setor, itens: resultado });
      return json({ ok: true });
    }

    // ---------- SOLICITAÇÕES ----------

    if (path === "/api/solicitacoes" && method === "POST") {
      const b = await request.json();
      const item = await env.DB.prepare("SELECT * FROM itens WHERE id = ?").bind(b.itemId).first();
      if (!item || item.quantidade < b.quantidade) {
        return json({ error: "Quantidade indisponível" }, 400);
      }
      await env.DB.prepare(
        "INSERT INTO solicitacoes (item_id, item_nome, unidade, quantidade, ot, solicitante, setor) VALUES (?, ?, ?, ?, ?, ?, ?)"
      ).bind(b.itemId, item.nome, item.unidade, b.quantidade, b.ot, b.solicitante, b.setor || "").run();

      await env.DB.prepare("UPDATE itens SET quantidade = quantidade - ? WHERE id = ?").bind(b.quantidade, b.itemId).run();

      await enviarEmail(env, {
        item: item.nome, quantidade: b.quantidade, unidade: item.unidade,
        ot: b.ot, solicitante: b.solicitante, setor: b.setor
      });

      return json({ ok: true });
    }

    const delOtMatch = path.match(/^\/api\/solicitacoes\/ot\/([^/]+)$/);
    if (delOtMatch && method === "DELETE") {
      await env.DB.prepare("DELETE FROM solicitacoes WHERE ot = ?").bind(decodeURIComponent(delOtMatch[1])).run();
      return json({ ok: true });
    }

    const aprovOtMatch = path.match(/^\/api\/solicitacoes\/ot\/([^/]+)\/aprovar$/);
    if (aprovOtMatch && method === "PATCH") {
      await env.DB.prepare("UPDATE solicitacoes SET status='aprovado' WHERE ot = ? AND status='pendente'").bind(decodeURIComponent(aprovOtMatch[1])).run();
      return json({ ok: true });
    }

    const devOtMatch = path.match(/^\/api\/solicitacoes\/ot\/([^/]+)\/devolver$/);
    if (devOtMatch && method === "PATCH") {
      const ot = decodeURIComponent(devOtMatch[1]);
      const { results } = await env.DB.prepare("SELECT * FROM solicitacoes WHERE ot = ? AND status != 'devolvido'").bind(ot).all();
      for (const sol of results) {
        await env.DB.prepare("UPDATE solicitacoes SET status='devolvido' WHERE id=?").bind(sol.id).run();
        await env.DB.prepare("UPDATE itens SET quantidade = quantidade + ? WHERE id=?").bind(sol.quantidade, sol.item_id).run();
      }
      return json({ ok: true });
    }

    const delSolMatch = path.match(/^\/api\/solicitacoes\/(\d+)$/);
    if (delSolMatch && method === "DELETE") {
      await env.DB.prepare("DELETE FROM solicitacoes WHERE id = ?").bind(delSolMatch[1]).run();
      return json({ ok: true });
    }

    const aprovMatch = path.match(/^\/api\/solicitacoes\/(\d+)\/aprovar$/);
    if (aprovMatch && method === "PATCH") {
      await env.DB.prepare("UPDATE solicitacoes SET status='aprovado' WHERE id=? AND status='pendente'").bind(aprovMatch[1]).run();
      return json({ ok: true });
    }

    const solMatch = path.match(/^\/api\/solicitacoes\/(\d+)\/devolver$/);
    if (solMatch && method === "PATCH") {
      const sol = await env.DB.prepare("SELECT * FROM solicitacoes WHERE id = ?").bind(solMatch[1]).first();
      if (sol && sol.status !== "devolvido") {
        await env.DB.prepare("UPDATE solicitacoes SET status='devolvido' WHERE id=?").bind(solMatch[1]).run();
        await env.DB.prepare("UPDATE itens SET quantidade = quantidade + ? WHERE id=?").bind(sol.quantidade, sol.item_id).run();
      }
      return json({ ok: true });
    }

    if (path === "/api/ot/email" && method === "POST") {
      const b = await request.json();
      if (!env.RESEND_API_KEY) return json({ error: "Email não configurado" }, 400);
      const linhas = b.itens.map(it => `<tr><td style="padding:6px 8px;border-bottom:1px solid #e5e7eb">${it.nome}</td><td style="padding:6px 8px;border-bottom:1px solid #e5e7eb">${it.qty} ${it.unidade}</td><td style="padding:6px 8px;border-bottom:1px solid #e5e7eb;color:#6b7280">${it.local||b.local||'—'}</td></tr>`).join('');
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: EMAIL_REMETENTE, to: b.email,
          subject: `OT ${b.ot} · NIU Experience Agency`,
          html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px">
            <div style="background:#0c0e16;border-radius:12px;padding:20px 24px;margin-bottom:20px">
              <div style="color:#fff;font-size:18px;font-weight:800">NIU <span style="color:#5b8cff">EXPERIENCE AGENCY</span></div>
              <div style="color:#9aa3b2;font-size:12px">Folha de Requisição de Material</div>
            </div>
            <h2 style="font-size:22px;color:#0f1117;margin:0 0 4px">${b.ot}</h2>
            <p style="color:#6b7280;margin:0 0 20px;font-size:14px">${b.local||''}</p>
            <table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:20px">
              <tr style="background:#f3f4f6"><td style="padding:8px;font-weight:700">Solicitante</td><td style="padding:8px">${b.solic}</td><td style="padding:8px;font-weight:700">Setor</td><td style="padding:8px">${b.setor||'—'}</td></tr>
            </table>
            <table style="width:100%;border-collapse:collapse;font-size:14px">
              <tr style="background:#f3f4f6"><th style="padding:8px;text-align:left">Item</th><th style="padding:8px;text-align:left">Qtd.</th><th style="padding:8px;text-align:left">Local</th></tr>
              ${linhas}
            </table>
            ${b.obs?`<div style="margin-top:16px;padding:12px;background:#f9fafb;border-radius:8px;font-size:13px;color:#374151"><b>Observações:</b> ${b.obs}</div>`:''}
            <p style="margin-top:24px;font-size:12px;color:#9ca3af">Gerado automaticamente · ${new Date().toLocaleString('pt-BR')}</p>
          </div>`
        })
      });
      return json({ ok: true });
    }

    if (path === "/api/email-ot" && method === "POST") {
      const b = await request.json();
      if (!env.RESEND_API_KEY) return json({ error: "Email não configurado" }, 400);
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: EMAIL_REMETENTE, to: b.to,
          subject: `Folha de Requisição: ${b.ot}`,
          html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
            <div style="background:#0c0e16;padding:20px 24px;border-radius:8px 8px 0 0">
              <span style="color:#fff;font-weight:800;font-size:18px">NIU</span>
              <span style="color:#9aa3b2;font-size:11px;margin-left:8px">EXPERIENCE AGENCY</span>
            </div>
            <div style="background:#fff;border:1px solid #e5e7eb;padding:24px">
              <h2 style="margin:0 0 4px;font-size:22px">${b.ot}</h2>
              <p style="color:#6b7280;margin:0 0 20px;font-size:13px">Folha de Requisição de Material</p>
              <table style="width:100%;font-size:13px;margin-bottom:16px">
                <tr><td style="color:#6b7280;padding:4px 0;width:120px">Solicitante</td><td><b>${b.solic}</b></td></tr>
                <tr><td style="color:#6b7280;padding:4px 0">Setor</td><td>${b.setor||'—'}</td></tr>
                <tr><td style="color:#6b7280;padding:4px 0">Local</td><td>${b.local||'—'}</td></tr>
                <tr><td style="color:#6b7280;padding:4px 0">Data</td><td>${b.data||'—'}</td></tr>
              </table>
              <table style="width:100%;border-collapse:collapse;font-size:13px">
                <thead><tr style="background:#f3f4f6"><th style="padding:8px;text-align:left">Item</th><th style="padding:8px;text-align:left">Qtd.</th><th style="padding:8px;text-align:left">Local</th></tr></thead>
                <tbody>${b.linhas}</tbody>
              </table>
              ${b.obs?`<p style="margin:16px 0 0;color:#374151;font-size:13px"><b>Obs:</b> ${b.obs}</p>`:''}
              <div style="margin-top:20px;padding-top:16px;border-top:1px solid #e5e7eb">
                <a href="${b.url}" style="background:#5b8cff;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-size:13px;font-weight:700">Ver OT online</a>
              </div>
            </div>
          </div>`
        })
      });
      return json({ ok: true });
    }

    if (path === "/api/ot/next-number" && method === "GET") {
      const year = new Date().getFullYear();
      const { results } = await env.DB.prepare(
        "SELECT COUNT(*) as total FROM solicitacoes WHERE ot LIKE ?"
      ).bind(`OT-${year}-%`).all();
      const seq = String((results[0]?.total || 0) + 1).padStart(4,'0');
      return json({ numero: `OT-${year}-${seq}` });
    }

    const otGetMatch = path.match(/^\/api\/ot\/(.+)$/);
    if (otGetMatch && method === "GET") {
      const ot = decodeURIComponent(otGetMatch[1]);
      const { results } = await env.DB.prepare("SELECT * FROM solicitacoes WHERE ot=? ORDER BY id").bind(ot).all();
      return json(results);
    }

    // ---------- UNIDADES FÍSICAS ----------
    if (path === "/api/unidades" && method === "POST") {
      const b = await request.json();
      // gera N unidades para um item
      const item = await env.DB.prepare("SELECT * FROM itens WHERE id=?").bind(b.itemId).first();
      if(!item) return json({error:"Item não encontrado"},404);
      const serials = [];
      for(let i=1; i<=b.quantidade; i++){
        const serial = `${(item.codigo||item.nome.slice(0,6).replace(/\s/g,'')).toUpperCase()}-${String(i).padStart(3,'0')}`;
        // tenta inserir, incrementa se já existe
        let s = serial, attempt = 0;
        while(attempt<99){
          try{
            await env.DB.prepare("INSERT INTO unidades (item_id, serial) VALUES (?,?)").bind(b.itemId, s).run();
            serials.push(s); break;
          }catch(e){ attempt++; s = `${serial}-${attempt}`; }
        }
      }
      return json({ serials });
    }

    if (path.match(/^\/api\/unidades\/item\/\d+$/) && method === "GET") {
      const itemId = path.split('/').pop();
      const { results } = await env.DB.prepare("SELECT u.*, s.ot, s.solicitante, s.local_uso FROM unidades u LEFT JOIN solicitacoes s ON s.id = (SELECT id FROM solicitacoes WHERE item_id=u.item_id AND status!='devolvido' ORDER BY id DESC LIMIT 1) WHERE u.item_id=? ORDER BY u.serial").bind(itemId).all();
      return json(results);
    }

    const unidadeMatch = path.match(/^\/api\/unidades\/(\d+)$/);
    if (unidadeMatch && method === "GET") {
      const u = await env.DB.prepare("SELECT u.*, i.nome, i.categoria, i.voltagem, i.modelo, i.unidade, i.codigo FROM unidades u JOIN itens i ON i.id=u.item_id WHERE u.id=?").bind(unidadeMatch[1]).first();
      return u ? json(u) : json({error:"Não encontrado"},404);
    }

    if (unidadeMatch && method === "PATCH") {
      const b = await request.json();
      await env.DB.prepare("UPDATE unidades SET status=? WHERE id=?").bind(b.status, unidadeMatch[1]).run();
      return json({ok:true});
    }

    // ---------- estático (frontend) ----------
    return env.ASSETS.fetch(request);
  }
};
